<?php
$db = new SQLite3('mysqlitedb.db');
if ($_POST["password2"] == "password") {
    echo "<h2>Records:</h2>";
	$results = $db->query('SELECT * FROM records');
	while ($row = $results->fetchArray()) {
        echo "<br> $row[0] \t $row[1] \t $row[2]\t $row[3]";
    }
}
else{
    echo "You are not admin";
}
?>
