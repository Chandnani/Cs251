#include<stdio.h>
void main(){
	printf("Helloworld!\n");
	printf("This must be a monolithic design\n");
}
void microkernel_getmsg(char *b){
	//TODO: getmsg feature
}
